# maven-project

Simple Maven Project to build in CICD Pipeline
test
test


test shana 11
